var t = "3";
var x ;

function test(){
	return true;
}
